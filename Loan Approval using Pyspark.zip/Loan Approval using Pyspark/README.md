# Loan Approval using Pyspark: Deployment on Docker and Kubernetes

## Overview

The objective of this project is to analyze and predict the outcomes of bank loan applications using a dataset containing 148,000 records of applicant and loan information. The dataset includes critical features such as loan amount, applicant's demographics, annual income, credit score, and the purpose of the loan, among others. The target variable, status, indicates whether a loan was approved (0) or denied (1). By studying patterns and trends within these features, the goal is to build a predictive model that can accurately forecast loan approval decisions, helping banks streamline their evaluation processes and manage risks effectively.

---

## Prerequisites

Before you begin, ensure you have the following installed:

- **Docker**: For containerization.
- **Kubernetes**: For orchestrating the containerized app.
- **Helm** (optional): For managing Kubernetes applications.
- **kubectl**: For interacting with your Kubernetes cluster.
- **Spark**: For running distributed data processing.

---

## Step 1: Docker Setup

### 1.1 Build the Docker Image

The first step is to **build the Docker image** for your project.

1. Clone the repository or navigate to the folder containing your project files (`M2-LoanApproval-Project.py`, `loan.csv`, and `requirements.txt`).
2. In the terminal, run the following command to build the Docker image:

```bash
docker build -t bdi-project .
docker run -p 5001:5000 bdi-project
docker ps
```

##Step 2: Push Docker Image to a Registry

```bash
docker tag bdi-project yourusername/bdi-project:latest
docker push yourusername/bdi-project:latest
```

## Step 3: Kubernetes Deployment

```bash
kubectl apply -f spark-deployment.yml
kubectl get sparkapplications
kubectl get pods
```

## 3.4 Access the Spark UI

```bash
kubectl port-forward svc/sparkui-loadbalancer 4040:4040 -n default
kubectl get svc sparkui-loadbalancer -n default
```

## 4.2 Scaling the Deployment

```bash
kubectl scale deployment spark-hello --replicas=3
```