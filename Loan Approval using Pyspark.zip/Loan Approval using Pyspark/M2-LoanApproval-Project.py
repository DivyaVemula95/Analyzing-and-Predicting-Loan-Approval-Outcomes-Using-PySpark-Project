import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.evaluation import BinaryClassificationEvaluator


import numpy as np #matematical computations
import matplotlib.pyplot as plt #plotting
import seaborn as sns #plotting
import warnings
import scipy.stats as ss #statistical computations
import math #mathematical computations
import pyspark.sql.functions as F
import pyspark.sql.types as T
import matplotlib.pyplot as plt

from itertools import product
from pyspark.ml import Pipeline, PipelineModel
from pyspark.ml.feature import StringIndexer, VectorAssembler, StandardScaler
from pyspark.ml.classification import LogisticRegression, RandomForestClassifier, GBTClassifier, NaiveBayes
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.sql.functions import col, when, sum, sort_array, collect_list, round

from pyspark.sql.types import StringType, BooleanType

# Initialize Spark session
spark = SparkSession.builder \
    .appName("LoanApprovalModel") \
    .getOrCreate()


# Define the path for the dataset CSV file (directly from your local file)
data_path = './loan.csv'  # Update with your actual file path if needed


# Function to load the CSV data into a Spark DataFrame
def load_data(file_path):
    """
    Load the CSV data into a Spark DataFrame.
    Args:
    - file_path (str): Path to the CSV file

    Returns:
    - df (DataFrame): Loaded DataFrame
    """
    df = spark.read.csv(file_path, header=True, inferSchema=True)
    return df


# Load the data
df = load_data(data_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dimensions of the dataset (rows, columns)

# COMMAND ----------

# DBTITLE 1,number of rows and columns
# Display number of rows and columns
num_rows = df.count()  # Get number of rows
num_columns = len(df.columns)  # Get number of columns

print(f"Number of rows: {num_rows}")
print(f"Number of columns: {num_columns}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Fields Description

# COMMAND ----------

# DBTITLE 1,Data Fields
df.describe()

# COMMAND ----------

# MAGIC %md
# MAGIC ## UnCleaned or Raw Data Schema

# COMMAND ----------

# DBTITLE 1,Raw Data Schema
# This section includes the initialization of Spark session and loading of data

# Display DataFrame Schema to understand data structure
display(df.printSchema())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Target Field(s) Described and Highlighted

# COMMAND ----------

# DBTITLE 1,Target variable
# Target variable: 'status' (approved/denied)
target_field = 'status'

# Describe target field
df.select(target_field).distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Count the number of loans by status

# COMMAND ----------

# DBTITLE 1,Product line by purchases

# Product line by purchases
df.select('status').groupBy('status').count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data statistical summary on raw data

# COMMAND ----------

# DBTITLE 1,Summary of Raw Data
# Summary of Raw Data
display(df.summary())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Raw Data table

# COMMAND ----------

# DBTITLE 1,display raw data
# Create a DataFrame

display(df.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check for Duplicate Rows

# COMMAND ----------

# DBTITLE 1,Duplicate Rows
num_duplicates = df.count() - df.distinct().count()
print(f"Number of duplicate rows: {num_duplicates}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Visualizations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot-1: Histogram For Raw Data

# COMMAND ----------

# DBTITLE 1,Missing Values Visualization
missing_values = df.select([F.sum(F.col(c).isNull().cast("int")).alias(c) for c in df.columns]).toPandas()

# COMMAND ----------

# DBTITLE 1,Plot On Raw Data
import seaborn as sns
import matplotlib.pyplot as plt
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, FloatType

# Set the figure size
plt.figure(figsize=(12, 6))

# Create the heatmap with improved aesthetics
sns.heatmap(missing_values, annot=True, cmap='viridis', cbar=False, fmt='g', linewidths=0.5, linecolor='white')

# Add a title to the heatmap
plt.title("Missing Values Heatmap", fontsize=16, fontweight='bold', color='black', pad=20)

# Display the plot
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot-2: Distribution of Numerical Columns

# COMMAND ----------

# DBTITLE 1,Distribution of Numerical Columns
# Select only numeric columns
numeric_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, (IntegerType, FloatType))]

# Collect data to Pandas for visualization
df_numeric = df.select(numeric_cols).toPandas()

# Plot histograms
plt.figure(figsize=(15, 10))
df_numeric.hist(bins=20, figsize=(15, 10), color='skyblue', edgecolor='black')
plt.suptitle("Distribution of Numerical Features")
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot-3: Boxplots for Outliers

# COMMAND ----------

# DBTITLE 1,Boxplots
plt.figure(figsize=(15, 10))
for i, col in enumerate(numeric_cols):
    plt.subplot(3, 3, i + 1)  # 3x3 grid for boxplots
    sns.boxplot(x=df_numeric[col], color='skyblue')
    plt.title(f'Boxplot of {col}')
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot-4: Correlation Matrix Heatmap

# COMMAND ----------

# DBTITLE 1,correlation matrix
# Compute the correlation matrix for numerical columns
corr_matrix = df_numeric.corr()

# Plot the correlation matrix
plt.figure(figsize=(12, 8))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='coolwarm', center=0, linewidths=0.5)
plt.title("Correlation Matrix Heatmap")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bar Plot for Categorical Features

# COMMAND ----------

# DBTITLE 1,Plot for categorical features
# Select categorical columns
categorical_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, StringType)]

# Number of categorical columns
num_categorical_cols = len(categorical_cols)

# Set number of columns for the subplot grid
num_cols = 2  # Reduce the number of columns to give more space
num_rows = (num_categorical_cols // num_cols) + (1 if num_categorical_cols % num_cols != 0 else 0)

# Create subplots dynamically with a larger figure size
plt.figure(figsize=(35, 25))  # Increase figure size for more space

for i, col in enumerate(categorical_cols):
    plt.subplot(num_rows, num_cols, i + 1)  # Dynamic rows and columns
    # Collect category counts and plot (using PySpark)
    category_counts = df.groupBy(col).count().toPandas()  # Convert to Pandas DataFrame for plotting
    sns.barplot(x=col, y='count', data=category_counts, palette='Set2')
    plt.title(f'Bar plot of {col}')
    plt.xticks(rotation=45)  # Rotate x-axis labels if necessary for better readability

# Adjust layout to add more space between the plots
plt.subplots_adjust(hspace=1.5, wspace=0.4)  # Increase space between subplots
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pairplot of Numerical Features

# COMMAND ----------

# DBTITLE 1,Plot for numerical Features
sns.pairplot(df_numeric, kind='scatter', plot_kws={'alpha': 0.7})
plt.suptitle("Pairplot of Numerical Features", y=1.02)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Cleaning

# COMMAND ----------

# DBTITLE 1,Handling missing, null, na, empty string values
from pyspark.sql import functions as F

# Fill NA and null values with 'Unknown' for categorical columns
df_cleaned = df.fillna({
    'loan_limit': 'Unknown', 'gender': 'Unknown', 'approv_in_adv': 'Unknown', 'loan_type': 'Unknown',
    'loan_purpose': 'Unknown', 'credit_worthiness': 'Unknown', 'business_or_commercial': 'Unknown',
    'neg_ammortization': 'Unknown', 'interest_only': 'Unknown', 'lump_sum_payment': 'Unknown',
    'construction_type': 'Unknown', 'occupancy_type': 'Unknown', 'secured_by': 'Unknown',
    'credit_type': 'Unknown', 'co-applicant_credit_type': 'Unknown', 'submission_of_application': 'Unknown',
    'region': 'Unknown', 'security_type': 'Unknown', 'high_interest_rate': 'Unknown', 'senior_age': 'Unknown'
})

# List of numerical columns
numerical_columns = ["loan_amount", "rate_of_interest", "interest_rate_spread", "upfront_charges",
                     "term", "property_value", "income", "credit_score", "ltv", "dtir1"]

# Fill NA and null values for numerical columns with the median
for column in numerical_columns:
    # Calculate median using approxQuantile
    median_value = df_cleaned.approxQuantile(column, [0.5], 0.1)[0]
    # Replace nulls with median
    df_cleaned = df_cleaned.withColumn(column, F.when(F.col(column).isNull(), median_value).otherwise(F.col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Visualizations on cleaned data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot1: PieChart

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt
from pyspark.sql.functions import col


def plot_pie_chart(spark_df, column_name):
    """
    Function to plot a pie chart for a specified column in a PySpark DataFrame using Seaborn.

    Parameters:
        spark_df (pyspark.sql.DataFrame): The PySpark DataFrame containing the data.
        column_name (str): The column for which to plot the pie chart.
    """
    # Convert the PySpark DataFrame to Pandas for visualization
    pdf = spark_df.groupBy(column_name).count().toPandas()

    # Prepare data for pie chart
    labels = pdf[column_name]
    sizes = pdf['count']

    # Plot using Seaborn's barplot (no direct pie chart support in sns)
    sns.barplot(x=labels, y=sizes, palette="Set2")
    plt.title(f'Distribution of {column_name}')
    plt.xlabel(column_name)
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.show()


# Create a PySpark DataFrame as an example
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("PieChartExample").getOrCreate()
data = [("Approved", "Male", "Type1"),
        ("Rejected", "Female", "Type2"),
        ("Pending", "Male", "Type1"),
        ("Approved", "Female", "Type2")]
columns = ["status", "gender", "credit_type"]
spark_df = spark.createDataFrame(data, columns)

# Plot bar charts for each specified column using Seaborn
plot_pie_chart(spark_df, 'status')
plot_pie_chart(spark_df, 'gender')
plot_pie_chart(spark_df, 'credit_type')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Summary of Data Cleaning:
# MAGIC
# MAGIC **Handling Missing Values:**
# MAGIC - Categorical columns were filled with "Unknown", ensuring that missing categorical data didn’t impact the analysis.
# MAGIC - Numerical columns were filled with the median value to avoid bias from outliers and provide a robust approach for missing values.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data statistical summary after cleaning

# COMMAND ----------

# DBTITLE 1,DataFrame Summary

# Display cleaned DataFrame
display(df_cleaned.summary())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Visualizations after Cleaning

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot1: Scatter Plot after Cleaning

# COMMAND ----------

# Convert to Pandas DataFrame
pd_df = df.toPandas()

# Scatter Plot of Loan Amount vs. Income
plt.figure(figsize=(10, 6))
sns.scatterplot(data=pdf, x="income", y="loan_amount", hue="status", palette="viridis")
plt.title('Scatter Plot of Loan Amount vs. Income')
plt.xlabel('Income')
plt.ylabel('Loan Amount')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Plot2: after cleaning

# COMMAND ----------

import matplotlib.pyplot as plt
import seaborn as sns

# Box Plot for Loan Amounts
plt.figure(figsize=(10, 6))
sns.boxplot(data=pd_df, y="loan_amount", color='#ff8c00')
plt.title('Box Plot of Loan Amounts')
plt.xlabel('Loan Amount')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Partition

# COMMAND ----------

# DBTITLE 1,Data splits for training and testing

# Split the data into training and testing sets
train_df, test_df = df_cleaned.randomSplit([0.7, 0.3], seed=42)

# COMMAND ----------

# DBTITLE 1,Good to review data before starting ML
display(train_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Transformation and feature engineering

# COMMAND ----------

# MAGIC %md
# MAGIC #### Summary of Data Transformations:
# MAGIC
# MAGIC **Transformations**:
# MAGIC - Categorical Encoding: Converting categorical variables to numerical form.
# MAGIC - Feature Scaling: Ensuring that numerical features are on a similar scale.
# MAGIC - Feature Engineering: Creating additional features that might better represent relationships in the data.

# COMMAND ----------

# DBTITLE 1,Converting string variables types to Integer types
# Import necessary libraries

from pyspark.ml.classification import LogisticRegression, NaiveBayes, LinearSVC, RandomForestClassifier
from pyspark.ml.feature import VectorAssembler, Tokenizer
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml import Pipeline
import re
import numpy as np

# Pipeline basic to be shared across model fitting and testing
from pyspark.ml.classification import LogisticRegression, NaiveBayes, LinearSVC, RandomForestClassifier
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml import Pipeline
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

indexer_label = StringIndexer(inputCol="status", outputCol="label")
indexed_df = indexer_label.fit(df_cleaned).transform(df_cleaned)
# Initialize base components
indexer = StringIndexer(inputCols=["loan_limit", "gender", "approv_in_adv", "loan_type", "loan_purpose",
                                   "credit_worthiness", "business_or_commercial", "neg_ammortization",
                                   "interest_only", "lump_sum_payment", "construction_type", "occupancy_type",
                                   "secured_by", "credit_type", "submission_of_application", "region", "security_type",
                                   "high_interest_rate", "senior_age"],
                        outputCols=["loan_limit_index", "gender_index", "approv_in_adv_index",
                                    "loan_type_index", "loan_purpose_index",
                                    "credit_worthiness_index", "business_or_commercial_index",
                                    "neg_ammortization_index", "interest_only_index", "lump_sum_payment_index",
                                    "construction_type_index", "occupancy_type_index", "secured_by_index",
                                    "credit_type_index",
                                    "submission_of_application_index", "region_index", "security_type_index",
                                    "high_interest_rate_index", "senior_age_index"])

assembler = VectorAssembler(inputCols=["year", "loan_amount", "rate_of_interest",
                                       "interest_rate_spread", "upfront_charges",
                                       "term", "property_value", "income", "credit_score", "ltv", "dtir1",
                                       "loan_limit_index", "gender_index", "approv_in_adv_index", "loan_type_index",
                                       "loan_purpose_index", "credit_worthiness_index", "business_or_commercial_index",
                                       "neg_ammortization_index", "interest_only_index", "lump_sum_payment_index",
                                       "construction_type_index", "occupancy_type_index", "secured_by_index",
                                       "credit_type_index",
                                       "submission_of_application_index", "region_index", "security_type_index",
                                       "high_interest_rate_index", "senior_age_index"],
                            outputCol="features")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Modeling

# COMMAND ----------

# DBTITLE 1,Multiple models from a common pipeline

# Pipeline basic to be shared across model fitting and testing
pipeline = Pipeline(stages=[])  # Must initialize with empty list!

# Initialize models
lr = LogisticRegression(maxIter=10, family='multinomial')
nb = NaiveBayes(modelType='gaussian')
svm = LinearSVC(labelCol="label", featuresCol="features")
rf = RandomForestClassifier(numTrees=50)

# Define parameter grids for each model
regParam = [0.01, 0.1]
elasticNetParam = [0.0, 0.5]
smoothing = [0.1, 1.0]
numTrees = [10, 20]
maxDepth = [5, 10]
svmRegParam = [0.01, 0.1]
svmMaxIter = [10, 20]

# Define parameter grids with pipelines
paramgrid_lr = ParamGridBuilder() \
    .baseOn({pipeline.stages: [indexer, indexer_label, assembler, lr]}) \
    .addGrid(lr.regParam, regParam) \
    .addGrid(lr.elasticNetParam, elasticNetParam) \
    .build()

paramgrid_nb = ParamGridBuilder() \
    .baseOn({pipeline.stages: [indexer, indexer_label, assembler, nb]}) \
    .addGrid(nb.smoothing, smoothing) \
    .build()

paramgrid_svm = ParamGridBuilder() \
    .baseOn({pipeline.stages: [indexer, indexer_label, assembler, svm]}) \
    .addGrid(svm.regParam, svmRegParam) \
    .addGrid(svm.maxIter, svmMaxIter) \
    .build()

paramgrid_rf = ParamGridBuilder() \
    .baseOn({pipeline.stages: [indexer, indexer_label, assembler, rf]}) \
    .addGrid(rf.numTrees, numTrees) \
    .addGrid(rf.maxDepth, maxDepth) \
    .build()

# Combine all parameter grids into one
paramGrid = paramgrid_lr + paramgrid_nb + paramgrid_svm + paramgrid_rf

# Evaluator Creation
evaluator = MulticlassClassificationEvaluator(metricName='f1')

# COMMAND ----------

# MAGIC %md
# MAGIC ## All 4 Classification Model Evaluations
# MAGIC   - Logistic Regression
# MAGIC   - Random Forest Classification
# MAGIC   - SVM Model Classification
# MAGIC   - Naive Baye's Model Classification

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model-1: Logistic Model Evaluation

# COMMAND ----------

# DBTITLE 1,Logistic Model Evaluation
test_stages_lr = [indexer, indexer_label, assembler,
                  lr]  # check a model (place any model here to test it; see config below)
lr_pipe = Pipeline(stages=test_stages_lr)
lr_fitted = lr_pipe.fit(train_df)
lr_results = lr_fitted.transform(test_df)
predictions_lr = lr_results.select('label', 'prediction')

metric_lr = evaluator.evaluate(predictions_lr)
print(f"The Logistic Model Performnce (f1) is {metric_lr}")

# COMMAND ----------

# DBTITLE 1,Logistic
from pyspark.mllib.evaluation import MulticlassMetrics

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Confusion matrix from labels and predictions
metrics = MulticlassMetrics(predictions_lr.select('label', 'prediction').rdd.map(tuple))
confusion_matrix = metrics.confusionMatrix().toArray()

# Pandas DataFrame from Spark confusion matrix
cnf_matrix = pd.DataFrame(confusion_matrix)

plt.figure(figsize=(10, 7))
p = sns.heatmap(cnf_matrix / np.sum(cnf_matrix), annot=True, fmt=".2%", linewidth=0.5, annot_kws={'fontsize': 10},
                cmap='RdBu')
# If you want numbers, instead of percent
# p = sns.heatmap(cnf_matrix, annot=True, fmt=",.1f", linewidth=0.5, annot_kws={'fontsize':10}, cmap='RdBu');

p.set(xlabel='Predicted', ylabel='Actual', title='Logistic Confusion Matrix');

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model-2: NaiveBayes Model Evaluation

# COMMAND ----------

# DBTITLE 1,NaiveBayes Model Evaluation
test_stages_nb = [indexer, indexer_label, assembler,
                  nb]  # check a model (place any model here to test it; see config below)
nb_pipe = Pipeline(stages=test_stages_nb)
nb_fitted = nb_pipe.fit(train_df)
nb_results = nb_fitted.transform(test_df)
predictions_nb = nb_results.select('label', 'prediction')

metric_nb = evaluator.evaluate(predictions_nb)
print(f"The NaiveBayes Model Performnce (f1) is {metric_nb}")

# COMMAND ----------

# DBTITLE 1,Naive Model
from pyspark.mllib.evaluation import MulticlassMetrics

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Confusion matrix from labels and predictions
metrics = MulticlassMetrics(predictions_nb.select('label', 'prediction').rdd.map(tuple))
confusion_matrix = metrics.confusionMatrix().toArray()

# Pandas DataFrame from Spark confusion matrix
cnf_matrix = pd.DataFrame(confusion_matrix)

plt.figure(figsize=(10, 7))
p = sns.heatmap(cnf_matrix / np.sum(cnf_matrix), annot=True, fmt=".2%", linewidth=0.5, annot_kws={'fontsize': 10},
                cmap='RdBu')
# If you want numbers, instead of percent
# p = sns.heatmap(cnf_matrix, annot=True, fmt=",.1f", linewidth=0.5, annot_kws={'fontsize':10}, cmap='RdBu');

p.set(xlabel='Predicted', ylabel='Actual', title='NaiveBayes Confusion Matrix');

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model-3: Support Vector Machine Model

# COMMAND ----------

# DBTITLE 1,LinearSVC Model
test_stages_svm = [indexer, indexer_label, assembler,
                   svm]  # check a model (place any model here to test it; see config below)
svm_pipe = Pipeline(stages=test_stages_svm)
svm_fitted = svm_pipe.fit(train_df)
svm_results = svm_fitted.transform(test_df)
predictions_svm = svm_results.select('label', 'prediction')

metric_svm = evaluator.evaluate(predictions_svm)
print(f"The Support Vector Machine Model Performnce (f1) is {metric_svm}")

# COMMAND ----------

# DBTITLE 1,LinearSVC
from pyspark.mllib.evaluation import MulticlassMetrics

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Confusion matrix from labels and predictions
metrics = MulticlassMetrics(predictions_svm.select('label', 'prediction').rdd.map(tuple))
confusion_matrix = metrics.confusionMatrix().toArray()

# Pandas DataFrame from Spark confusion matrix
cnf_matrix = pd.DataFrame(confusion_matrix)

plt.figure(figsize=(10, 7))
p = sns.heatmap(cnf_matrix / np.sum(cnf_matrix), annot=True, fmt=".2%", linewidth=0.5, annot_kws={'fontsize': 10},
                cmap='RdBu')
# If you want numbers, instead of percent
# p = sns.heatmap(cnf_matrix, annot=True, fmt=",.1f", linewidth=0.5, annot_kws={'fontsize':10}, cmap='RdBu');

p.set(xlabel='Predicted', ylabel='Actual', title='LinearSVC Confusion Matrix');

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model-4: RandomForestClassifier Model Evaluation

# COMMAND ----------

# DBTITLE 1,RandomForestClassifier Model
test_stages_rf = [indexer, indexer_label, assembler,
                  svm]  # check a model (place any model here to test it; see config below)
rf_pipe = Pipeline(stages=test_stages_rf)
rf_fitted = rf_pipe.fit(train_df)
rf_results = rf_fitted.transform(test_df)
predictions_rf = rf_results.select('label', 'prediction')

metric_rf = evaluator.evaluate(predictions_rf)
print(f"The RandomForestClassifier Model Performnce (f1) is {metric_rf}")

# COMMAND ----------

# DBTITLE 1,RandomForestClassifier
from pyspark.mllib.evaluation import MulticlassMetrics

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Confusion matrix from labels and predictions
metrics = MulticlassMetrics(predictions_rf.select('label', 'prediction').rdd.map(tuple))
confusion_matrix = metrics.confusionMatrix().toArray()

# Pandas DataFrame from Spark confusion matrix
cnf_matrix = pd.DataFrame(confusion_matrix)

plt.figure(figsize=(10, 7))
p = sns.heatmap(cnf_matrix / np.sum(cnf_matrix), annot=True, fmt=".2%", linewidth=0.5, annot_kws={'fontsize': 10},
                cmap='RdBu')
# If you want numbers, instead of percent
# p = sns.heatmap(cnf_matrix, annot=True, fmt=",.1f", linewidth=0.5, annot_kws={'fontsize':10}, cmap='RdBu');

p.set(xlabel='Predicted', ylabel='Actual', title='RandomForestClassifier Confusion Matrix');

# COMMAND ----------

# MAGIC %md
# MAGIC ## CrossValidation on 4 Models
# MAGIC   - multi-model pipeline

# COMMAND ----------

# DBTITLE 1,Run all models in the parameterized pipelines
# The common empty pipeline
# The common evaluator
# The paramGrid, which includes models and their pipelines
cv = CrossValidator() \
    .setEstimator(pipeline) \
    .setEvaluator(evaluator) \
    .setEstimatorParamMaps(paramGrid) \
    .setNumFolds(2) \
    .setParallelism(4)

fitted_grid = cv.fit(train_df)
print(f"model averages: {fitted_grid.avgMetrics}")

# COMMAND ----------

# DBTITLE 1,Simple summary of models
import numpy as np

num_models = len(fitted_grid.getEstimatorParamMaps())
print(f"Ran {num_models} models")
print(f"Model metrics are: {fitted_grid.avgMetrics}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Evaluate models (from multi-model pipeline)

# COMMAND ----------

# DBTITLE 1,Best & Worst model
import numpy as np

print("Best Model:")
print(fitted_grid.getEstimatorParamMaps()[np.argmax(fitted_grid.avgMetrics)])
print()  # This adds a blank line between the outputs
print("Worst Model:")
print(fitted_grid.getEstimatorParamMaps()[np.argmin(fitted_grid.avgMetrics)])

# COMMAND ----------

# DBTITLE 1,Model metrics for plot
import re
from pyspark.ml.tuning import CrossValidatorModel


def paramGrid_model_name(model):
    params = [v for v in model.values() if type(v) is not list]
    name = [v[-1] for v in model.values() if type(v) is list][0]
    name = re.match(r'([a-zA-Z]*)', str(name)).groups()[0]
    return f"{name}{params}"


def cv_metrics(cv: CrossValidatorModel):
    """
    Returns metrics and model names when CrossValidator is used to run multiple models, in parameter pipelines.
    """
    # Resulting metric and model description
    # get the metric from the CrossValidator's resulting avgMetrics
    # get the model name & params from the paramGrid
    # put them together here:
    measures = zip(cv.avgMetrics, [paramGrid_model_name(m) for m in cv.getEstimatorParamMaps()])
    metrics, model_names = zip(*measures)
    return metrics, model_names


metrics, model_names = cv_metrics(fitted_grid)

metric_name = fitted_grid.getEvaluator().getMetricName()
print(metric_name)

# COMMAND ----------

# DBTITLE 1,Graph comparision of model metrics
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_context('notebook')
sns.set_style('white')
sns.set_palette("bright")


def add_metric_labels(metrics):
    for i in range(len(metrics)):
        plt.text(i, metrics[i], f"{metrics[i]:.3f}", ha='center', fontsize=10)


plt.figure(figsize=(10, 5))

pdf = pd.DataFrame(zip(metrics, model_names), columns=['r2', 'model'])
sns.barplot(data=pdf, x='model', y='r2').set(title="Model Metrics")
plt.xticks(rotation=45)
add_metric_labels(metrics)

# COMMAND ----------

# DBTITLE 1,summary attribute
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.mllib.evaluation import BinaryClassificationMetrics, MulticlassMetrics


# import sparkdl

def feature_importance(model, predictions, schema_name='features'):
    """
    Given (non-regression) model and it's predictions,
    Returns Pandas DataFrame of features scores, sorted by importance.
    """
    idxs = [f['idx'] for f in predictions.schema[schema_name].metadata["ml_attr"]["attrs"]['numeric']]
    names = [f['name'] for f in predictions.schema[schema_name].metadata["ml_attr"]["attrs"]['numeric']]

    scores = list(model.featureImportances.toArray())
    pdf = pd.DataFrame(list(zip(idxs, names, scores)), columns=['index', 'name', 'score'])
    pdf.sort_values('score', ascending=False, inplace=True)
    return pdf


def classification_metrics(predictions: DataFrame, label='label', prediction='prediction'):
    """
    Summary metrics (ROC, PR, etc.) for given predictions.
    Returned metrics dictionary, and the confusion matrix.
    Provides F-measure using beta values: https://machinelearningmastery.com/fbeta-measure-for-machine-learning
    A smaller beta value, such as 0.5, gives more weight to precision and less to recall,
    whereas a larger beta value, such as 2.0, gives less weight to precision and more weight to recall in the calculation of the score.
    For stocks, we are interested in precision (correctly calling positive increases)
    """
    metrics_b = BinaryClassificationMetrics(predictions.select(label, prediction).rdd.map(tuple))
    metrics = {}
    metrics['PR AUC'] = metrics_b.areaUnderPR
    metrics['ROC AUC'] = metrics_b.areaUnderROC
    metrics_m = MulticlassMetrics(predictions.select(label, prediction).rdd.map(tuple))
    metrics['F0.5 Score'] = metrics_m.fMeasure(label=1.0, beta=0.5)
    metrics['F1 Score'] = metrics_m.fMeasure(label=1.0, beta=1.0)
    metrics['F2 Score'] = metrics_m.fMeasure(label=1.0, beta=2.0)
    metrics['Recall'] = metrics_m.recall(label=1)
    metrics['Precision'] = metrics_m.precision(1)
    metrics['Accuracy'] = metrics_m.accuracy
    return metrics, metrics_m.confusionMatrix().toArray()


def precision_recall(pred_df: DataFrame, col_name):
    """
    Output: precision, recall used in evaluation function
    """
    rdd_pred = pred_df.select([col_name, 'label']).rdd
    metrics_m = MulticlassMetrics(rdd_pred)
    precision = metrics_m.precision(1)
    recall = metrics_m.recall(label=1)
    f2 = metrics_m.fMeasure(1.0, 2.0)
    f1 = metrics_m.fMeasure(1.0, 1.0)
    f05 = metrics_m.fMeasure(1.0, 0.5)
    return (precision, recall, f2, f1, f05)


def threshold_tuning(valid_df: DataFrame):
    """
    Input: a validated df
    Output: a panda df that contains thresholds from 0-1 and associated precision/recall/f2 score
    """
    pr_results = []
    preds_new = valid_df
    preds_new = preds_new.withColumn('pred_probability', firstelement('probability'))
    thresholds = np.arange(start=0.1, stop=1.1, step=0.1)
    c = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10']
    i = 0
    for threshold in thresholds:
        preds_new = preds_new.withColumn(c[i], F.when(preds_new["pred_probability"].cast(T.DoubleType()) >= threshold,
                                                      1.0).otherwise(0.0).cast(T.DoubleType()))
        i = i + 1
    for i in range(len(thresholds) - 1):
        precision, recall, f2, f1, f05 = precision_recall(preds_new, c[i])
        pr_results.append((thresholds[i], precision, recall, f2, f1, f05))
    pr_df = pd.DataFrame(pr_results).rename(
        columns={0: 'Threshold', 1: 'Precision', 2: 'Recall', 3: 'f2-score', 4: 'f1-score', 5: 'f0.5-score'})
    return pr_df


# Function to graph first position of the dense vector probability
# Used in threshold_tuning function
firstelement = udf(lambda item: float(item[1]), T.FloatType())


class CurveMetrics(BinaryClassificationMetrics):
    """
    Helper function to plot roc curve
    """

    def __init__(self, *args):
        super(CurveMetrics, self).__init__(*args)

    def _to_list(self, rdd):
        points = []
        for row in rdd.collect():
            # Results are returned as type scala.Tuple2,
            # which doesn't appear to have a py4j mapping
            points += [(float(row._1()), float(row._2()))]
        return points

    def get_curve(self, method):
        rdd = getattr(self._java_model, method)().toJavaRDD()
        return self._to_list(rdd)


def evaluate(preds_train: DataFrame, preds_valid: DataFrame, model, label='label', features='features',
             cm_percent=True):
    """
    Input: predicted model for train and validation set, model
    Output: PySpark DataFrame of evaluation metrics for class 0, 1
    Confusion Matrix, PR-Curve
    """

    print(str(model))
    tr_metrics, _ = classification_metrics(preds_train)
    ts_metrics, confusion_matrix = classification_metrics(preds_valid)
    print(f"{'Metric': <10} {'Train': >7} {'Test': >7}")
    for key in tr_metrics.keys():
        print(f"{key: <10} {tr_metrics[key]: >7,.4f} {ts_metrics[key]: >7,.4f}")

    print('                                        Validation Plots')
    fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(12, 12))

    preds_valid_pr = threshold_tuning(preds_valid)
    # plot the Precision-Recall curve
    sns.set(font_scale=1, style='whitegrid')
    sns.lineplot(x='Recall', y='Precision', data=preds_valid_pr, label='PR Curve', ax=axes[0, 0])
    axes[0, 0].set_title('Precision-Recall Curve')
    axes[0, 0].legend()

    # Used by plot ROC AUC
    rdd_valid_b = preds_valid.select(label, 'probability').rdd.map(
        lambda row: (float(row['probability'][1]), float(row[label])))
    # plot ROC AUC
    metrics_valid = CurveMetrics(rdd_valid_b)
    points_roc = metrics_valid.get_curve('roc')
    x_val = [x[0] for x in points_roc]
    y_val = [x[1] for x in points_roc]
    sns.lineplot(x=x_val, y=y_val, color='lightsteelblue', label='ROC AUC', ax=axes[1, 0])
    # Get the xy data from the lines so that we can shade
    l1 = axes[1, 0].lines[0]
    x1 = l1.get_xydata()[:, 0]
    y1 = l1.get_xydata()[:, 1]
    axes[1, 0].fill_between(x1, y1, color="lightblue", alpha=0.3)
    axes[1, 0].set_ylim([0.1, 1])
    axes[1, 0].set_xlabel('FPR (1-Specificity)')
    axes[1, 0].set_ylabel('TPR (Recall)')
    axes[1, 0].set_title('ROC AUC curve (Validation)')
    axes[1, 0].legend()

    # Plot confusion matrix
    cm = confusion_matrix
    confusion_matrix = pd.DataFrame(cm)
    if cm_percent:
        sns.heatmap(confusion_matrix / np.sum(confusion_matrix), annot=True, fmt=".1%", linewidth=0.5, cmap='Blues',
                    ax=axes[1, 1])
    else:
        sns.heatmap(cnf_matrix, annot=True, fmt=",.1f", linewidth=0.5, annot_kws={'fontsize': 10}, cmap='RdBu',
                    ax=axes[1, 1])
    size = int(preds_valid.count())
    size = f'{size:,}'
    axes[1, 1].set_title('Confusion Matrix - N={}'.format(size))
    axes[1, 1].set_ylabel('Actual Values')
    axes[1, 1].set_xlabel('Predicted Values')
    plt.show()

    # Features
    try:
        pdf = feature_importance(model, preds_valid, schema_name=features)
        sns.catplot(data=pdf, y='name', x='score', kind='bar', orient='h', height=7, aspect=1.7).set(
            title='Feature Importance');
        plt.show()
    except AttributeError:
        print("Cannot display feature importance")
        pass


# COMMAND ----------

# DBTITLE 1,Run the best model
model = fitted_grid.bestModel.stages[-1]
train_predictions = fitted_grid.bestModel.transform(train_df)
test_predictions = fitted_grid.bestModel.transform(test_df)

# COMMAND ----------

# DBTITLE 1,Display Predictions
# display(test_predictions)
display(test_predictions.select('features', 'status', 'probability', 'prediction'))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Best Model Evaluation

# COMMAND ----------

# DBTITLE 1,Evaluate the best model
evaluate(train_predictions, test_predictions, model, features='features')
